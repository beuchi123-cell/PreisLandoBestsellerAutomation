# PreisLandoBestsellerAutomation 0.1.0

Automatische Bestseller-Pflege fuer PlentyONE / plentyShop LTS.

## Was das Plugin macht

- wertet echte Verkaufsauftraege der letzten X Tage aus
- standardmaessig 30 Tage
- zaehlt normale Varianten sowie Bundle-/Set-Hauptpositionen
- zaehlt Bundle-/Set-Komponenten nicht doppelt
- filtert nach Auftragsstatus von/bis
- kann einzelne Status zusaetzlich ausschliessen
- kann auf bestimmte Auftragsherkuenfte begrenzt werden; leer = alle
- sortiert nach verkaufter Stueckzahl
- pflegt automatisch die Top-X Varianten im Tag `Bestseller`
- entfernt den Tag von Varianten, die nicht mehr in den Top-X sind
- Cron: taeglich
- geschuetzter manueller REST-Start: `POST /rest/v1/preislando-bestseller/run` (OAuth erforderlich)

## Sicherheitslogik

Beim ersten Installieren sind:

- `Automatik aktiv = Nein`
- `Testmodus = Ja`

Dadurch veraendert das Plugin nach der Installation noch keine Tags.
Erst Statusbereich kontrollieren, dann aktivieren.

Wenn bei einer Auswertung keine passenden Verkaufspositionen gefunden werden, entfernt das Plugin aus Sicherheitsgruenden keine bestehenden Bestseller-Tags.

## Empfohlene PreisLando-Einstellungen

- Zeitraum: 30 Tage
- Top: 30 Varianten
- Herkuenfte: leer (alle Kanaele)
- Tag: Bestseller
- Status von/bis: an euren echten Auftragsworkflow anpassen

## ShopBuilder

Nach erfolgreicher Tag-Pflege:

1. Shop > ShopBuilder > Startseite
2. Ueberschrift `Unsere Bestseller`
3. Artikel > Artikelliste
4. Art der Artikelliste: Artikel mit Tags
5. Tag: Bestseller
6. z.B. 5 Artikel gleichzeitig sichtbar / Slider

## Installation

Eigene Plugins werden in PlentyONE ueber Git zum System hinzugefuegt.
Siehe INSTALLATION.txt in diesem Paket.
